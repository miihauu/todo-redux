import React from 'react';
import { connect } from 'react-redux';



const Todos = ({ todos }) => {
        const todoList = ({todos}) => {
            todos.map(todo => (
                <div className="collectionItem" key={todo.id}>
                    <span>
                        {todo.text}
                    </span>
                </div>
            ));
        }   
      

    return (
        <div className="todos collection">
            {todoList}
            {console.log(todos)}
        </div>
    )
}



const mapStateToProps = state => {
    return {
        todos: state.todos
        
    }
}

export default connect(mapStateToProps)(Todos);
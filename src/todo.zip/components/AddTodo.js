import React from 'react';
import { addTodo } from '../actions'
import { connect } from 'react-redux';

class AddTodo extends React.Component {
    state = { content: ''};
    

    updateState = (e) => {
        this.setState({
            content: e.target.value
        })
    }

    onSubmit = e => {
        e.preventDefault();
        addTodo(this.state.content)
    }

  
     render() {
         return ( 
             <div>
                 <form onSubmit={e => this.onSubmit(e)}>
                     <label>Add new todo:</label>
                     <input type="text" onChange={e => this.updateState(e)}/>
                     
                 </form>
             </div>
          );
    }

     
}

const mapDispatchToProps = (dispatch) => {
    return {
        addTodo: (text) => dispatch(addTodo(text))
    }
}



 
export default connect(mapDispatchToProps)(AddTodo);